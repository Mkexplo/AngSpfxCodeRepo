/* tslint:disable */
require("./SpfxAngWebpartWebPart.module.css");
const styles = {
  spfxAngWebpart: 'spfxAngWebpart_6c65a16d',
  teams: 'teams_6c65a16d',
  welcome: 'welcome_6c65a16d',
  welcomeImage: 'welcomeImage_6c65a16d',
  links: 'links_6c65a16d'
};

export default styles;
/* tslint:enable */