declare const styles: {
    spfxAngWebpart: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=SpfxAngWebpartWebPart.module.scss.d.ts.map