import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AngRtComponentComponent } from './ang-rt-component.component';

describe('AngRtComponentComponent', () => {
  let component: AngRtComponentComponent;
  let fixture: ComponentFixture<AngRtComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ AngRtComponentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AngRtComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
