import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-ang-rt-component',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './ang-rt-component.component.html',
  styleUrls: ['./ang-rt-component.component.css']
})
export class AngRtComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
