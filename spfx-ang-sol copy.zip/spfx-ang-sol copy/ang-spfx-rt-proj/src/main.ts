import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { createCustomElement } from '@angular/elements';
import { createApplication } from '@angular/platform-browser';
import { AngRtComponentComponent } from './app/ang-rt-component/ang-rt-component.component';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment';
import 'zone.js/dist/zone.js';

(async () => {

  const app = await createApplication({
    providers: [
      /* your global providers here */
    ],
  });

  const angElement = createCustomElement(AngRtComponentComponent, {
    injector: app.injector,
  });

  customElements.define('ang-element', angElement);

})();
